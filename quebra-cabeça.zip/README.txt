Bom dia xovens devs!

Nesta pasta estão todos os arquivos do quebra-cabeça que está no slide, mas de forma mais direta.
Não esqueça de fazer o download dos arquivos CSS do Bootstrap para colocar na pasta ou utilizar a CDN!
https://getbootstrap.com/docs/5.1/getting-started/download/

Para montagem:
>index.html que é nosso esqueleto;
->compra+imagem.txt: pegar o codigo e colocar fora do container flex do index.html
->formularios.txt: pegar o codigo e colocar dentro do container flex do index.html
-->dados pessoais.txt: pegar o codigo e colocar dentro do form flex
-->cartao.txt: pegar o codigo e colocar dentro do form flex
->navbar.txt:pegar o codigo e colocar dentro do body index.html
-->botaoPesquisa: pegar o codigo e colocar dentro da navbar;
-->script-navbar-js: pegar o codigo e colocar ao final dentro da body;